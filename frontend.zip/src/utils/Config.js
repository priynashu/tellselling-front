// export const backend_url = "https://app-dev.tellselling.tech/salesrooms/";
// /
export const backend_url = "http://localhost:5000/";
