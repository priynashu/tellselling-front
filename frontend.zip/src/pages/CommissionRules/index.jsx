import { AccountTopbar } from '../../components';

const CommissionRules = () => {
  return <AccountTopbar />;
};

export { CommissionRules };
