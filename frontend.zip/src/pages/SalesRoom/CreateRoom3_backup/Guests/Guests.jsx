import React, { Component } from 'react'

export class Guests extends Component {
  render() {
    return (
      <>
        <h1>Guests</h1>
      </>
    )
  }
}

export default Guests